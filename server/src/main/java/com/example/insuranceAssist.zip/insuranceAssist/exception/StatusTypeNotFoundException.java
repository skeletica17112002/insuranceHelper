package com.example.insuranceAssist.exception;

public class StatusTypeNotFoundException extends Exception {

    public StatusTypeNotFoundException(){}

    public StatusTypeNotFoundException(String message){
        super(message);
    }

}
