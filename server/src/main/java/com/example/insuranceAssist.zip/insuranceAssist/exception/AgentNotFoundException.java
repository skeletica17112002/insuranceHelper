package com.example.insuranceAssist.exception;

public class AgentNotFoundException extends Exception{

    public AgentNotFoundException(){}

    public AgentNotFoundException(String message){
        super(message);
    }

}
